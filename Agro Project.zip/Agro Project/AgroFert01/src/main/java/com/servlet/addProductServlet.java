package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.servlet.ConnectionProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class addProductServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String productName = request.getParameter("productName");
        String category = request.getParameter("category");
        int stock = Integer.parseInt(request.getParameter("stock"));
        String rackLocation = request.getParameter("rackLocation");
        String expiryDate = request.getParameter("expiryDate");
        String price =(String) request.getParameter("price");

        Connection con = null;
        try {
            con = ConnectionProvider.getConnection();

            // Using a prepared statement to prevent SQL injection.
            PreparedStatement pstmt = con.prepareStatement(
                    "INSERT INTO Products (productName, category, stock, rackLocation, expiryDate,price) VALUES (?, ?, ?, ?, ?,?)");
            pstmt.setString(1, productName);
            pstmt.setString(2, category);
            pstmt.setInt(3, stock);
            pstmt.setString(4, rackLocation);
            pstmt.setString(5, expiryDate);
pstmt.setString(6, price);
            // Executing the update query.
            int rowsAffected = pstmt.executeUpdate();

            // Redirect to Dashboard.jsp with a success message
            if (rowsAffected > 0) {
                response.sendRedirect("Dashboard.jsp?success=Product added successfully");
            } else {
                response.sendRedirect("Dashboard.jsp?error=Failed to add product");
            }

        } catch (Exception e) {
            e.printStackTrace(); // Consider logging the exception instead of just printing it.
            response.sendRedirect("Dashboard.jsp?error=An error occurred during product addition");
        } finally {
            try {
                // Close the database connection in a finally block to ensure it is closed even if an exception occurs.
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace(); // Handle or log the exception.
            }
        }
    }
}
