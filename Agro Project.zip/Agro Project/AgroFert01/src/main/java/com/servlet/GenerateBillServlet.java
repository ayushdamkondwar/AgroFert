package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class GenerateBillServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve selected product IDs from the form
        String[] selectedProducts = request.getParameterValues("selectedProducts");

        if (selectedProducts != null && selectedProducts.length > 0) {
            // Establish the database connection (use your ConnectionProvider)
            Connection con = ConnectionProvider.getConnection();

            // Prepare the HTML table header with Bootstrap classes
            out.println("<html><head><title>Bill</title>");
            out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\">");
            out.println("</head><body class=\"container\">");
            out.println("<center><h2 class=\"mt-4\">AgroFert</h2></center><br><br>");
            out.println("<h3 class=\"mt-4\">Bill</h3>");
            out.println("<table class=\"table table-bordered\">");
            out.println("<thead class=\"thead-dark\"><tr><th>Product Name</th><th>Price</th><th>Quantity</th></tr></thead><tbody>");

            double totalAmount = 0.0;

            try {
                Statement stmt = con.createStatement();

                // Iterate through selected product IDs
                for (String productId : selectedProducts) {
                    // Retrieve product details from the database based on the product ID
                    ResultSet rs = stmt.executeQuery("SELECT * FROM products WHERE id = " + productId);

                    while (rs.next()) {
                        String productName = rs.getString("productName");
                        double price = rs.getDouble("price");

                        // For simplicity, assuming quantity is 1 (modify as per your requirements)
                        int quantity = 1;

                        // Calculate total amount for this product
                        double productTotalAmount = price * quantity;

                        // Display the product details in the table
                        out.println("<tr><td>" + productName + "</td><td>" + price + "</td><td>" + quantity + "</td></tr>");

                        // Add the product's total amount to the overall total
                        totalAmount += productTotalAmount;
                    }

                    rs.close();
                }

                stmt.close();
            } catch (Exception e) {
                out.println(e);
            } finally {
                // Close the database connection
                if (con != null) {
                    try {
                        con.close();
                    } catch (Exception e) {
                        out.println(e);
                    }
                }
            }

            // Print the total amount row
            out.println("<tr class=\"table-info\"><td colspan='2'><b>Total Amount</b></td><td><b>" + totalAmount + "</b></td></tr></tbody></table>");
            out.println("<br><br><button id='printBillBtn' class='btn btn-primary'>Print Bill </button>");
            
            
            out.println("<script>");
            out.println("document.getElementById('printBillBtn').addEventListener('click', function () {");
            out.println("    window.print();");
            out.println("});");
            out.println("</script>");

            // Close the HTML table and document
            out.println("</body></html>");
        } else {
            // No products selected
            out.println("<html><head><title>Bill</title></head><body>");
            out.println("<h2>No products selected</h2>");
            out.println("</body></html>");
        }

        out.close();
    }
}