package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.servlet.ConnectionProvider; // Assuming this is a utility class providing a database connection.

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

    Connection con;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String pwd = req.getParameter("pwd");

        try {
            con = ConnectionProvider.getConnection(); // Assuming ConnectionProvider is a class providing a database connection.
            
            // Using a prepared statement to prevent SQL injection.
            PreparedStatement pstmt = con.prepareStatement("INSERT INTO users(email, pwd) VALUES (?, ?)");
            pstmt.setString(1, email);
            pstmt.setString(2, pwd);

            // Executing the update query.
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("success");
            // Writing the response to the client.
            PrintWriter pw = resp.getWriter();
            if (rowsAffected > 0) {
                pw.println(email + " Registered Successfully...");
             // Redirect to index.jsp on successful registration
                resp.sendRedirect("index.jsp");
            } else {
                pw.println("Registration failed. Please try again.");
            }

        } catch (Exception e) {
            e.printStackTrace(); // Consider logging the exception instead of just printing it.
            resp.getWriter().println("An error occurred during registration.");
        } finally {
            try {
                // Close the database connection in a finally block to ensure it is closed even if an exception occurs.
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace(); // Handle or log the exception.
            }
        }
    }
}
