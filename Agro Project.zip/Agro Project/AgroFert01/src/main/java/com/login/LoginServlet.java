package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.servlet.ConnectionProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("pwd");

        Connection con = null;
        try {
            con = ConnectionProvider.getConnection();

            // Using a prepared statement to prevent SQL injection.
            PreparedStatement pstmt = con.prepareStatement("SELECT * FROM users WHERE email=? AND pwd=?");
            pstmt.setString(1, email);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // Valid login, set up a session
                HttpSession session = request.getSession();
                session.setAttribute("email", email);

                // Redirect to Dashboard.jsp on successful login
                response.sendRedirect("Dashboard.jsp");
            } else {
                // Invalid login, display a message and forward to login.jsp
                PrintWriter out = response.getWriter();
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Invalid login. Please try again.');");
                out.println("location='index.jsp';");
                out.println("</script>");
            }

        } catch (Exception e) {
            e.printStackTrace(); // Consider logging the exception instead of just printing it.
            response.getWriter().println("An error occurred during login.");
        } finally {
            try {
                // Close the database connection in a finally block to ensure it is closed even if an exception occurs.
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace(); // Handle or log the exception.
            }
        }
    }
}
