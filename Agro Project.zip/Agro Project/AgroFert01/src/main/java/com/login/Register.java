package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.servlet.ConnectionProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServlet;

public class Register extends HttpServlet  {
       
   Connection con;
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		
		try {
			
		con = ConnectionProvider.getConnection();
		PreparedStatement pstmt = con.prepareStatement("insert into users(email,pwd) values(?,?)");
		pstmt.setString(1, email);
		pstmt.setString(2, pwd);
		
		pstmt.executeUpdate();
		
		PrintWriter pw = response.getWriter();
		pw.println(email+ "Registered Successfully...");
		
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
